﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.GameContent.UI;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.UI;

namespace MarkofTheSlayer
{
	public class MarkofTheSlayer : Mod
	{
		public static ModHotKey PraetorDash;
		
        public override void Load()
        {
            PraetorDash = RegisterHotKey("Praetor Dash", "T");
        }
        
        public override void Unload()
        {
            PraetorDash = null;
        }
	}
}

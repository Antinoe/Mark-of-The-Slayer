using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace MarkofTheSlayer.Items.Weapons
{
    public class Chaingun : ModItem {
        public override void SetStaticDefaults() {
            DisplayName.SetDefault("Chaingun");
            Tooltip.SetDefault("Shoots bullets"
                + "\nDesigned for sustained volleys, the Chaingun deals high damage at a very high rate of fire.");
        }

        public override Vector2? HoldoutOffset() {
            return new Vector2(-7, 0);
        }

        public override void SetDefaults() {
            //item.CloneDefaults(ItemID.SniperRifle);
            //item.damage = 5;
			item.damage = 15;
            item.crit = 50;
            item.ranged = true;
            item.width = 60;
            item.height = 20;
            item.useAnimation = 7;
            item.useTime = 7;
            item.useStyle = 5;
            item.noMelee = true;
            item.knockBack = 8;
            item.value = 40000;
            item.rare = 0;
            item.UseSound = SoundID.Item40;
            item.autoReuse = true;
            item.shoot = 10;
            item.shootSpeed = 16f;
            item.useAmmo = AmmoID.Bullet;
			item.UseSound = mod.GetLegacySoundSlot(SoundType.Custom, "Sounds/Weapons/Chaingun/CGNFIRE2");
        }

        /*public override bool ReforgePrice(ref int reforgePrice, ref bool canApplyDiscount) {
            reforgePrice /= 2;
            return base.ReforgePrice(ref reforgePrice, ref canApplyDiscount);
        }*/

        //public override bool AltFunctionUse(Player player)
        //{
        //    return true;
        //}

        //public override bool CanUseItem(Player player)
        //{
        //    if (player.altFunctionUse == 2) {
        //        //item.ranged = false;
        //        player.scope = true;

        //        return false;
        //        //item.useAnimation = 999;
        //        //item.useTime = 999;
        //    }
        //    else {
        //        //item.ranged = true;
        //        //item.useAnimation = 28;
        //        //item.useTime = 28;
        //    }
        //    return base.CanUseItem(player);
        //}


    }
}

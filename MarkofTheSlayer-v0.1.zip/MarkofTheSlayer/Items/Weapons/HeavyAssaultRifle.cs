using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace MarkofTheSlayer.Items.Weapons
{
    public class HeavyAssaultRifle : ModItem {
        public override void SetStaticDefaults() {
            DisplayName.SetDefault("Heavy Assault Rifle");
            Tooltip.SetDefault("Shoots bullets"
                + "\nWith high velocity rounds, the Heavy Assault Rifle is ideal for hitting fast-moving targets.");
        }

        public override Vector2? HoldoutOffset() {
            return new Vector2(-7, 0);
        }

        public override void SetDefaults() {
            //item.CloneDefaults(ItemID.SniperRifle);
            item.damage = 40;
            item.crit = 29;
            item.ranged = true;
            item.width = 60;
            item.height = 20;
            item.useAnimation = 10;
            item.useTime = 10;
            item.useStyle = 5;
            item.noMelee = true;
            item.knockBack = 8;
            item.value = 40000;
            item.rare = 0;
            item.UseSound = SoundID.Item40;
            item.autoReuse = true;
            item.shoot = 10;
            item.shootSpeed = 16f;
            item.useAmmo = AmmoID.Bullet;
			item.UseSound = mod.GetLegacySoundSlot(SoundType.Custom, "Sounds/Weapons/HeavyAssaultRifle/HMGFIRE1");
        }

        /*public override bool ReforgePrice(ref int reforgePrice, ref bool canApplyDiscount) {
            reforgePrice /= 2;
            return base.ReforgePrice(ref reforgePrice, ref canApplyDiscount);
        }*/

        //public override bool AltFunctionUse(Player player)
        //{
        //    return true;
        //}

        //public override bool CanUseItem(Player player)
        //{
        //    if (player.altFunctionUse == 2) {
        //        //item.ranged = false;
        //        player.scope = true;

        //        return false;
        //        //item.useAnimation = 999;
        //        //item.useTime = 999;
        //    }
        //    else {
        //        //item.ranged = true;
        //        //item.useAnimation = 28;
        //        //item.useTime = 28;
        //    }
        //    return base.CanUseItem(player);
        //}


    }
}

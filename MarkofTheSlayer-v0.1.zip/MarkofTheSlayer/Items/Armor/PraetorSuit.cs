using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace MarkofTheSlayer.Items.Armor
{
	[AutoloadEquip(EquipType.Body)]
	class PraetorFullplate : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Praetor Fullplate");
		}
		public override void SetDefaults()
		{
			item.width = 26;
			item.height = 18;
			item.rare = 1;
			item.value = 50000;
			item.defense = 50;
		}
		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
			return (head.type == mod.ItemType("PraetorHelmet") && body.type == mod.ItemType("PraetorFullplate") && legs.type == mod.ItemType("PraetorGreaves"));
		}
		public override void UpdateArmorSet(Player player)
		{
			player.setBonus = "+50 defense" + "\r\n"
				+ "Allows you to slide down walls";
			player.statDefense += 50;
			player.spikedBoots += 1;
		}
	}
	[AutoloadEquip(EquipType.Legs)]
	class PraetorGreaves : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Praetor Greaves");
		}
		public override void SetDefaults()
		{
			item.width = 22;
			item.height = 18;
			item.rare = 1;
			item.value = 3000;
			item.defense = 50;
		}
	}
	[AutoloadEquip(EquipType.Head)]
	class PraetorHelmet : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Praetor Helmet");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 22;
			item.rare = 1;
			item.value = 3000;
			item.defense = 50;
		}
	}
}
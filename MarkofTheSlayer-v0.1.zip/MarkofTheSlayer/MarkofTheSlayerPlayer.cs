﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameInput;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;

namespace MarkofTheSlayer
{
    public class MarkofTheSlayerPlayer : ModPlayer
    {
		//Using code from the DodgeMod as a base for the Praetor Dash.
		int dashCoolDown = 0;
		public bool praetorDash = false;
		public override void PostUpdate()
		{
		if(dashCoolDown <= 0)
		{
			if (MarkofTheSlayer.PraetorDash.JustPressed)
			{
			if(praetorDash == true)
			{
			int dashDir = player.direction;
			if(player.controlRight)
				{
				dashDir = 1;
				}
			else if(player.controlLeft)
				{
				dashDir = -1;
				}
			//player.immune = true;
			//player.immuneTime = 30;
			dashCoolDown = 50;
			if(player.velocity.Y == 0)
				{
				player.velocity.X = 10 * dashDir;
				player.velocity.Y = 0;
				}
			else
				{
				player.velocity.X = 10 * dashDir;
				player.velocity.Y = 0;
				}
			}
			}
		}
		else
			{
			dashCoolDown--;
			}
		}
		
		public static MarkofTheSlayerPlayer ModPlayer(Player player)
		{
			return player.GetModPlayer<MarkofTheSlayerPlayer>();
		}
    }
}
